package Main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import ToDo.ToDoViewDao;
import ToDo.ToDo_View;

public class Start {

	public static void main(String[] args) throws IOException{

		System.out.println("Welcome in To Do Management Application");
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		while(true) {
			System.out.println("Press 1 to view TODO");
			System.out.println("Press 2 to add new TODO");
			System.out.println("Press 3 to exit");
			
			int todo_status = Integer.parseInt(br.readLine());
			
			if(todo_status==1) {
				ToDoViewDao.ShowToDoDB();
			}else if(todo_status==2) {
				System.out.println("Enter ID : ");
				int id = Integer.parseInt(br.readLine());
				
				System.out.println("Enter Topic : ");
				String topic = br.readLine();
				
				System.out.println("Enter Date : ");
				String date = br.readLine();
				
				System.out.println("Enter Status : ");
				String status = br.readLine();
				
				ToDo_View td = new ToDo_View(id, topic, date, status);
				boolean answer = ToDoViewDao.insertToDoDB(td);
				if(answer) {
					System.out.println("Added Successfully..........");
				}else {
					System.out.println("Something went wrong");
				}
			}else if(todo_status==3) {
				System.out.println("Thanks you using our application");
				break;
			}else {
				
			}
		}
	}
}
