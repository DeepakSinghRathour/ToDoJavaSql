package ToDo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class ToDoViewDao {

	public static boolean insertToDoDB(ToDo_View td) {
		boolean f = false;
		
		try {
			Connection con = ConnectionProvider.createC();
			String q = "insert into TODO(id, topic, date, status) values(?,?,?,?)";
			// Prepared Statement
			PreparedStatement pstmt = con.prepareStatement(q);
			pstmt.setInt(1, td.getId());
			pstmt.setString(2, td.getTopic());
			pstmt.setString(3, td.getDate());
			pstmt.setString(4, td.getStatus());
			pstmt.executeUpdate();
			f=true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return f;
	}

	public static void ShowToDoDB() {
		try {
			Connection con = ConnectionProvider.createC();
			String q = "select * from TODO;";
			Statement stmt = con.createStatement();
			ResultSet set = stmt.executeQuery(q);
			while(set.next()) {
				int id = set.getInt("id");
				String topic = set.getString("topic");
				String date = set.getString("date");
				String status = set.getString("status");
				
				System.out.println("ID -->    "+id);
				System.out.println("Topic --> "+topic);
				System.out.println("Date -->  "+date);
				System.out.println("Status -->"+status);
				
				System.out.println("******************************");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
