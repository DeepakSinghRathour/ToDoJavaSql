package ToDo;

public class ToDo_View {
	
	private int id;
	private String topic;
	private String date;
	private String status;
	
	public ToDo_View(int id, String topic, String date, String status) {
		super();
		this.id = id;
		this.topic = topic;
		this.date = date;
		this.status = status;
	}
	
	public ToDo_View(String topic, String date, String status) {
		super();
		this.topic = topic;
		this.date = date;
		this.status = status;
	}

	public ToDo_View() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ToDo_View [id=" + id + ", topic=" + topic + ", date=" + date + ", status=" + status + "]";
	}
	
}
